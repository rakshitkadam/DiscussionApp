package com.stabstudio.discussionapp.UI;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.stabstudio.discussionapp.R;

public class BottomMenuActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_menu);
    }

}
